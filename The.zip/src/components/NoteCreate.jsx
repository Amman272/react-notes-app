function NoteCreate(props){

    return(
<div >
                  <p>{props.note_id}  {props.title}</p>
                  <h3></h3>
                </div>
)}

export default NoteCreate